class InvalidUpdateType(Exception):
    pass

class MalformedUpdate(Exception):
    pass